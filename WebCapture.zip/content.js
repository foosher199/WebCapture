// Content script is now just a placeholder since html2canvas is loaded via manifest
// We can add any additional content script functionality here if needed 